import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent {
  pid:any=""
  prod:any
  constructor(private ar:ActivatedRoute,private ds:DataService){
    ar.params.subscribe(p=>this.pid=p["id"])
    console.log(this.pid)
    ds.getItem(this.pid).then(r=>r.json()).then(data=>this.prod=data)
    console.log(this.prod)

  }

}
